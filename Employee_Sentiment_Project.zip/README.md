# 🧠 Employee Sentiment Analysis

This project analyzes employee sentiment using internal messages to identify positive, neutral, or negative trends, flag potential flight risks, and forecast sentiment behavior over time.

## 📌 Project Goals

- Label messages with sentiment using NLP
- Explore sentiment distribution with EDA
- Score and rank employees monthly
- Identify flight risk employees
- Predict future sentiment using regression

## 📁 Files Included

- `Employee_Sentiment_Analysis_Project.ipynb`: Full project notebook with all code and outputs
- `report.docx`: Written documentation for submission
- `README.md`: Project summary and guide

## 📊 Tools Used

- Python, pandas, seaborn, matplotlib
- TextBlob (sentiment analysis)
- scikit-learn (modeling)

## 📈 Key Features

- Rolling 30-day analysis for flight risk
- Bar plots of top positive/negative employees
- R² metric to evaluate linear model performance

## ✅ Status

Completed and submitted as the final project for LLM Assessment.

